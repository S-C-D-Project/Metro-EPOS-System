CREATE PROCEDURE [dbo].[DecreaseProductQuantity]
    @ProductID INT,
    @QtyToDecrease INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM Product WHERE ProductID = @ProductID)
    BEGIN
        UPDATE Product
        SET stockQuantity = CASE 
                            WHEN stockQuantity >= @QtyToDecrease THEN stockQuantity - @QtyToDecrease
                            ELSE 0
                       END
        WHERE ProductID = @ProductID;
  END
End
go

