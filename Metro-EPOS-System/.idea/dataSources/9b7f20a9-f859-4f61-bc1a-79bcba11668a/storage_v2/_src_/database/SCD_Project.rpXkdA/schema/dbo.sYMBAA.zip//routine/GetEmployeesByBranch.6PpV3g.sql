CREATE PROCEDURE GetEmployeesByBranch
@BranchID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        Employeeid,
        Name,
        Password,
        Email,

        BranchID,
        Salary,
        JoiningDate,
        LeavingDate,
        IsActive,
        FirstTime,
        Role
    FROM Employee
    WHERE BranchID = @BranchID;
END;
go

