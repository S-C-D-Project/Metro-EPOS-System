CREATE PROCEDURE GetBranchById
    @BranchID INT
AS
BEGIN
    SELECT 
        Code, 
        Address, 
        PhoneNumber, 
        NumberOfEmployees, 
        IsActive
    FROM Branch
    WHERE Code = @BranchID;
END;
go

