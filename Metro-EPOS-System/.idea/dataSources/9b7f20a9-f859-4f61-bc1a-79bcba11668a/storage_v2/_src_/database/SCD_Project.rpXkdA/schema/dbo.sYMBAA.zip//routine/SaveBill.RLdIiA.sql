CREATE PROCEDURE [dbo].[SaveBill]
    @cashAmount INT,
    @returnAmount INT,
    @totalBill INT,
    @additionalCharges INT,
    @salesTaxAmount INT,
    @discount FLOAT,
    @productList ProductListType READONLY,  -- Table-valued parameter
    @billId INT OUTPUT
AS
BEGIN
    -- Insert data into the Bill table
    INSERT INTO Bill (cashAmount, returnAmount, totalBill, additionalCharges, salesTaxAmount, discount)
    VALUES (@cashAmount, @returnAmount, @totalBill, @additionalCharges, @salesTaxAmount, @discount);

    -- Get the generated billId
    SET @billId = SCOPE_IDENTITY(); 

    -- Insert products into the BillProduct table
    INSERT INTO BillProduct (billId, productId, quantity, price)
    SELECT @billId, productId, quantity, price
    FROM @productList;

    -- Return the billId as output
    SELECT @billId AS BillId;
END;
select * from Bill
go

