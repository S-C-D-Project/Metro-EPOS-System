CREATE PROCEDURE UPDATEEMPLOYEE
    @employeeId int,
    @name nvarchar(50),
    @email nvarchar(50),
    @branchId int,
    @salary money,
    @joiningDate date,
    @leavingDate date,
    @active bit,
    @firstTime bit,
    @role nvarchar(50)
AS
BEGIN
    -- Assuming you have an Employees table that matches these columns
    UPDATE Employee
    SET
        name = @name,
        email = @email,
        branchId = @branchId,
        salary = @salary,
        joiningDate = @joiningDate,
        leavingDate = @leavingDate,
        isActive = @active,
        firstTime = @firstTime,
        role = @role
    WHERE
       EmployeeID=@employeeId
END;
go

