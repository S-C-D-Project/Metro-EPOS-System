CREATE PROCEDURE [dbo].[getProduct]
    @ProductID INT,
	@branchid int
AS
BEGIN
    -- Retrieve the product details for the given ProductID
    SELECT * 
    FROM Product
    WHERE ProductID = @ProductID and BranchId=@branchid;
END;
go

