CREATE PROCEDURE [dbo].[GetEmployeeByCredentials]
    @EmployeeNumber NVARCHAR(50),
    @Password NVARCHAR(255)
AS
BEGIN
    -- Select employee details based on the provided EmployeeNumber and Password
    SELECT 
        EmployeeID,
        Name,
        Email,
        Branchid,
        Salary,
        JoiningDate,
        LeavingDate,
        IsActive,
        BranchID,
        FirstTime,
		role
    FROM 
        Employee
    WHERE 
        employeeid = @EmployeeNumber AND Password = @Password;
END;
go

