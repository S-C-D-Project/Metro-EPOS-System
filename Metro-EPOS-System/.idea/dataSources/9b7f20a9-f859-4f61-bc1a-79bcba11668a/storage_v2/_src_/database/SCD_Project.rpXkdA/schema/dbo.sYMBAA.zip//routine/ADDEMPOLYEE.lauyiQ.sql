CREATE PROCEDURE ADDEMPOLYEE
    @Name NVARCHAR(50),
    @Email NVARCHAR(50),
    @Salary INT,
    @BranchId INT,
    @Role NVARCHAR(50),
    @Password NVARCHAR(50)
AS
BEGIN
    SET @Password='123';
    DECLARE @joiningdate DATETIME = GETDATE();

    -- Here, we're just inserting the procedure parameters into a hypothetical Employee table.
    -- I'm assuming the Employee table has these columns:
    -- [Name, Password, Email, BranchID, Salary, JoiningDate, UnknownColumn1, UnknownColumn2, UnknownColumn3, Role]
    INSERT INTO Employee([Name],[Password],[Email],[BranchID],[Salary],[JoiningDate],LeavingDate,IsActive,FirstTime,[Role])
    VALUES (@Name, @Password, @Email, @BranchId, @Salary, @joiningdate, null, 1, 1, @Role)
END
go

