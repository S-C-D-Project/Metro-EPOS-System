CREATE PROCEDURE InsertProductData
    @BranchId INT,
    @ProductName NVARCHAR(255),
    @Category NVARCHAR(100),
    @OriginalPrice FLOAT,
    @SalePrice INT,
    @PricePerUnit FLOAT,
    @StockQuantity INT,
    @Productsize NVARCHAR(255),
    @ProductID INT OUTPUT,
	@salesTAX float,
	@Man NVARCHAR(255)
AS
BEGIN
    -- Insert data into the Products table
    INSERT INTO Product (BranchID, productName, category, originalPrice, salePrice, pricePerUnit, ProductSize, stockQuantity,salestax,Manufacturer)
    VALUES (@BranchId, @ProductName, @Category, @OriginalPrice, @SalePrice, @PricePerUnit, @Productsize, @StockQuantity,@salesTAX,@Man);

    -- Set the OUTPUT parameter to the inserted ProductID
    SET @ProductID = SCOPE_IDENTITY();  -- SCOPE_IDENTITY() retrieves the last inserted identity value
END;
go

