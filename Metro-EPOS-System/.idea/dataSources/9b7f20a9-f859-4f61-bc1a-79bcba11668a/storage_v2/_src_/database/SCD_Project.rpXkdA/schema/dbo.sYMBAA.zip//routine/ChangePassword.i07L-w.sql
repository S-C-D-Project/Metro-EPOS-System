CREATE PROCEDURE ChangePassword @NewPassword NVARCHAR(256),
                                @EmployeeID INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Employee
    SET Password = @NewPassword, FirstTime=0
    WHERE EmployeeID = @EmployeeID;
END;
go

