CREATE PROCEDURE GetSalesTaxPrice
AS
BEGIN
    SELECT price FROM Tax WHERE type = 'Sales Tax';
END;
go

